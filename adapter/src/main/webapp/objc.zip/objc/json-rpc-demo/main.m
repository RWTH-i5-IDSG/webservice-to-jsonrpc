//
//  main.m
//  json-rpc-demo
//
//  Created by Derek Bowen on 7/17/12.
//  Copyright (c) 2012 Demiurgic Software, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
